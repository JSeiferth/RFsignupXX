/// A simple function that adds two numbers.
pub fn add(a: i32, b: i32) -> i32 {
    a + b
}
